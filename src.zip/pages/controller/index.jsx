import Watering from "../../components/controller_comp/watering";

const Controller = () => {
  return (
    <div>
      <Watering></Watering>
    </div>
  );
};

export default Controller;
