export default function Moisture() {
  return (
    <>
      <p>수분입니당</p>
    </>
  );
}
