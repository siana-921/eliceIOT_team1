export default function Temperature() {
  return (
    <>
      <p>온도입니당</p>
    </>
  );
}
