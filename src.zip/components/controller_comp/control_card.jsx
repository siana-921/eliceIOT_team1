import React from "react";

const ControlCard = () => {
  return (
    <div>
      <div style={{ width: "500px", height: "800px", backgroundColor: "grey" }}>
        현재 습도[물주기버튼]
      </div>
    </div>
  );
};

export default ControlCard;
